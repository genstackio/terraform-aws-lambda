import json


def handler(event, context):
    body = {'status': 'success'}
    return {
        "statusCode": 200,
        "body": json.dumps(body),
        "headers": {'Content-Type': 'application/json;charset=utf-8'}
    }
